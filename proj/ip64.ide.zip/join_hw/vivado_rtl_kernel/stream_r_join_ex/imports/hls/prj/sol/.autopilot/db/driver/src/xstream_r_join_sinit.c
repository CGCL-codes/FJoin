// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xstream_r_join.h"

extern XStream_r_join_Config XStream_r_join_ConfigTable[];

XStream_r_join_Config *XStream_r_join_LookupConfig(u16 DeviceId) {
	XStream_r_join_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XSTREAM_R_JOIN_NUM_INSTANCES; Index++) {
		if (XStream_r_join_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XStream_r_join_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XStream_r_join_Initialize(XStream_r_join *InstancePtr, u16 DeviceId) {
	XStream_r_join_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XStream_r_join_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XStream_r_join_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

