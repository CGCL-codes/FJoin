// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read)
//        bit 7  - auto_restart (Read/Write)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0  - Channel 0 (ap_done)
//        bit 1  - Channel 1 (ap_ready)
//        others - reserved
// 0x10 : Data signal of s_stream_length
//        bit 31~0 - s_stream_length[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of r_window_length
//        bit 31~0 - r_window_length[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of s_result_max
//        bit 31~0 - s_result_max[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of window_in_ms
//        bit 31~0 - window_in_ms[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of s_result
//        bit 31~0 - s_result[31:0] (Read/Write)
// 0x34 : Data signal of s_result
//        bit 31~0 - s_result[63:32] (Read/Write)
// 0x38 : reserved
// 0x3c : Data signal of s_stream
//        bit 31~0 - s_stream[31:0] (Read/Write)
// 0x40 : Data signal of s_stream
//        bit 31~0 - s_stream[63:32] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of s_info
//        bit 31~0 - s_info[31:0] (Read/Write)
// 0x4c : Data signal of s_info
//        bit 31~0 - s_info[63:32] (Read/Write)
// 0x50 : reserved
// 0x54 : Data signal of r_window
//        bit 31~0 - r_window[31:0] (Read/Write)
// 0x58 : Data signal of r_window
//        bit 31~0 - r_window[63:32] (Read/Write)
// 0x5c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XSTREAM_S_JOIN_CONTROL_ADDR_AP_CTRL              0x00
#define XSTREAM_S_JOIN_CONTROL_ADDR_GIE                  0x04
#define XSTREAM_S_JOIN_CONTROL_ADDR_IER                  0x08
#define XSTREAM_S_JOIN_CONTROL_ADDR_ISR                  0x0c
#define XSTREAM_S_JOIN_CONTROL_ADDR_S_STREAM_LENGTH_DATA 0x10
#define XSTREAM_S_JOIN_CONTROL_BITS_S_STREAM_LENGTH_DATA 32
#define XSTREAM_S_JOIN_CONTROL_ADDR_R_WINDOW_LENGTH_DATA 0x18
#define XSTREAM_S_JOIN_CONTROL_BITS_R_WINDOW_LENGTH_DATA 32
#define XSTREAM_S_JOIN_CONTROL_ADDR_S_RESULT_MAX_DATA    0x20
#define XSTREAM_S_JOIN_CONTROL_BITS_S_RESULT_MAX_DATA    32
#define XSTREAM_S_JOIN_CONTROL_ADDR_WINDOW_IN_MS_DATA    0x28
#define XSTREAM_S_JOIN_CONTROL_BITS_WINDOW_IN_MS_DATA    32
#define XSTREAM_S_JOIN_CONTROL_ADDR_S_RESULT_DATA        0x30
#define XSTREAM_S_JOIN_CONTROL_BITS_S_RESULT_DATA        64
#define XSTREAM_S_JOIN_CONTROL_ADDR_S_STREAM_DATA        0x3c
#define XSTREAM_S_JOIN_CONTROL_BITS_S_STREAM_DATA        64
#define XSTREAM_S_JOIN_CONTROL_ADDR_S_INFO_DATA          0x48
#define XSTREAM_S_JOIN_CONTROL_BITS_S_INFO_DATA          64
#define XSTREAM_S_JOIN_CONTROL_ADDR_R_WINDOW_DATA        0x54
#define XSTREAM_S_JOIN_CONTROL_BITS_R_WINDOW_DATA        64

