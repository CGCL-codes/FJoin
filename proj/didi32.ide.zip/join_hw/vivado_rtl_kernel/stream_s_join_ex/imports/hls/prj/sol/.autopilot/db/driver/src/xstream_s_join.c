// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
/***************************** Include Files *********************************/
#include "xstream_s_join.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XStream_s_join_CfgInitialize(XStream_s_join *InstancePtr, XStream_s_join_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XStream_s_join_Start(XStream_s_join *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_AP_CTRL) & 0x80;
    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XStream_s_join_IsDone(XStream_s_join *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XStream_s_join_IsIdle(XStream_s_join *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XStream_s_join_IsReady(XStream_s_join *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XStream_s_join_EnableAutoRestart(XStream_s_join *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XStream_s_join_DisableAutoRestart(XStream_s_join *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_AP_CTRL, 0);
}

void XStream_s_join_Set_s_stream_length(XStream_s_join *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_STREAM_LENGTH_DATA, Data);
}

u32 XStream_s_join_Get_s_stream_length(XStream_s_join *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_STREAM_LENGTH_DATA);
    return Data;
}

void XStream_s_join_Set_r_window_length(XStream_s_join *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_R_WINDOW_LENGTH_DATA, Data);
}

u32 XStream_s_join_Get_r_window_length(XStream_s_join *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_R_WINDOW_LENGTH_DATA);
    return Data;
}

void XStream_s_join_Set_s_result_max(XStream_s_join *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_RESULT_MAX_DATA, Data);
}

u32 XStream_s_join_Get_s_result_max(XStream_s_join *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_RESULT_MAX_DATA);
    return Data;
}

void XStream_s_join_Set_window_in_ms(XStream_s_join *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_WINDOW_IN_MS_DATA, Data);
}

u32 XStream_s_join_Get_window_in_ms(XStream_s_join *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_WINDOW_IN_MS_DATA);
    return Data;
}

void XStream_s_join_Set_s_result(XStream_s_join *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_RESULT_DATA, (u32)(Data));
    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_RESULT_DATA + 4, (u32)(Data >> 32));
}

u64 XStream_s_join_Get_s_result(XStream_s_join *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_RESULT_DATA);
    Data += (u64)XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_RESULT_DATA + 4) << 32;
    return Data;
}

void XStream_s_join_Set_s_stream(XStream_s_join *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_STREAM_DATA, (u32)(Data));
    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_STREAM_DATA + 4, (u32)(Data >> 32));
}

u64 XStream_s_join_Get_s_stream(XStream_s_join *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_STREAM_DATA);
    Data += (u64)XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_STREAM_DATA + 4) << 32;
    return Data;
}

void XStream_s_join_Set_s_info(XStream_s_join *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_INFO_DATA, (u32)(Data));
    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_INFO_DATA + 4, (u32)(Data >> 32));
}

u64 XStream_s_join_Get_s_info(XStream_s_join *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_INFO_DATA);
    Data += (u64)XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_S_INFO_DATA + 4) << 32;
    return Data;
}

void XStream_s_join_Set_r_window(XStream_s_join *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_R_WINDOW_DATA, (u32)(Data));
    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_R_WINDOW_DATA + 4, (u32)(Data >> 32));
}

u64 XStream_s_join_Get_r_window(XStream_s_join *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_R_WINDOW_DATA);
    Data += (u64)XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_R_WINDOW_DATA + 4) << 32;
    return Data;
}

void XStream_s_join_InterruptGlobalEnable(XStream_s_join *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_GIE, 1);
}

void XStream_s_join_InterruptGlobalDisable(XStream_s_join *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_GIE, 0);
}

void XStream_s_join_InterruptEnable(XStream_s_join *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_IER);
    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_IER, Register | Mask);
}

void XStream_s_join_InterruptDisable(XStream_s_join *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_IER);
    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_IER, Register & (~Mask));
}

void XStream_s_join_InterruptClear(XStream_s_join *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XStream_s_join_WriteReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_ISR, Mask);
}

u32 XStream_s_join_InterruptGetEnabled(XStream_s_join *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_IER);
}

u32 XStream_s_join_InterruptGetStatus(XStream_s_join *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XStream_s_join_ReadReg(InstancePtr->Control_BaseAddress, XSTREAM_S_JOIN_CONTROL_ADDR_ISR);
}

