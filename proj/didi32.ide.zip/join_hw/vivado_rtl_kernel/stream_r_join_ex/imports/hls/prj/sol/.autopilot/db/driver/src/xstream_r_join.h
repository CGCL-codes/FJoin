// ==============================================================
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2019.2 (64-bit)
// Copyright 1986-2019 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XSTREAM_R_JOIN_H
#define XSTREAM_R_JOIN_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xstream_r_join_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#else
typedef struct {
    u16 DeviceId;
    u32 Control_BaseAddress;
} XStream_r_join_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XStream_r_join;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XStream_r_join_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XStream_r_join_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XStream_r_join_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XStream_r_join_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XStream_r_join_Initialize(XStream_r_join *InstancePtr, u16 DeviceId);
XStream_r_join_Config* XStream_r_join_LookupConfig(u16 DeviceId);
int XStream_r_join_CfgInitialize(XStream_r_join *InstancePtr, XStream_r_join_Config *ConfigPtr);
#else
int XStream_r_join_Initialize(XStream_r_join *InstancePtr, const char* InstanceName);
int XStream_r_join_Release(XStream_r_join *InstancePtr);
#endif

void XStream_r_join_Start(XStream_r_join *InstancePtr);
u32 XStream_r_join_IsDone(XStream_r_join *InstancePtr);
u32 XStream_r_join_IsIdle(XStream_r_join *InstancePtr);
u32 XStream_r_join_IsReady(XStream_r_join *InstancePtr);
void XStream_r_join_EnableAutoRestart(XStream_r_join *InstancePtr);
void XStream_r_join_DisableAutoRestart(XStream_r_join *InstancePtr);

void XStream_r_join_Set_r_stream_length(XStream_r_join *InstancePtr, u32 Data);
u32 XStream_r_join_Get_r_stream_length(XStream_r_join *InstancePtr);
void XStream_r_join_Set_s_window_length(XStream_r_join *InstancePtr, u32 Data);
u32 XStream_r_join_Get_s_window_length(XStream_r_join *InstancePtr);
void XStream_r_join_Set_r_result_max(XStream_r_join *InstancePtr, u32 Data);
u32 XStream_r_join_Get_r_result_max(XStream_r_join *InstancePtr);
void XStream_r_join_Set_window_in_ms(XStream_r_join *InstancePtr, u32 Data);
u32 XStream_r_join_Get_window_in_ms(XStream_r_join *InstancePtr);
void XStream_r_join_Set_r_result(XStream_r_join *InstancePtr, u64 Data);
u64 XStream_r_join_Get_r_result(XStream_r_join *InstancePtr);
void XStream_r_join_Set_r_stream(XStream_r_join *InstancePtr, u64 Data);
u64 XStream_r_join_Get_r_stream(XStream_r_join *InstancePtr);
void XStream_r_join_Set_r_info(XStream_r_join *InstancePtr, u64 Data);
u64 XStream_r_join_Get_r_info(XStream_r_join *InstancePtr);
void XStream_r_join_Set_s_window(XStream_r_join *InstancePtr, u64 Data);
u64 XStream_r_join_Get_s_window(XStream_r_join *InstancePtr);

void XStream_r_join_InterruptGlobalEnable(XStream_r_join *InstancePtr);
void XStream_r_join_InterruptGlobalDisable(XStream_r_join *InstancePtr);
void XStream_r_join_InterruptEnable(XStream_r_join *InstancePtr, u32 Mask);
void XStream_r_join_InterruptDisable(XStream_r_join *InstancePtr, u32 Mask);
void XStream_r_join_InterruptClear(XStream_r_join *InstancePtr, u32 Mask);
u32 XStream_r_join_InterruptGetEnabled(XStream_r_join *InstancePtr);
u32 XStream_r_join_InterruptGetStatus(XStream_r_join *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
